import java.awt.Color;
import java.awt.Graphics;

public class Car {
    private Color bodyColor;
    private int height;
    private int width;
    private int xPosition;
    private int yPosition;

    public Car(Color bodyColor, int height, int width, int x, int y) {
        this.bodyColor = bodyColor;
        this.height = height;
        this.width = width;
        this.xPosition = x;
        this.yPosition = y;
        this.setBounds(x, y, width, height);
    }

    private void setBounds(int x, int y, int width, int height) {
    }

    public Car(int i, int height, int width, int xPosition, Color red) {
    }

    public void drawVehicle(Graphics g) {
        g.setColor(bodyColor);
        g.fillRect(xPosition, yPosition, width, height);

        g.setColor(Color.BLACK);
        g.fillOval(xPosition, yPosition + height, width/2, height/2);
        g.fillOval(xPosition + width - width/2, yPosition + height, width/2, height/2);
    }
}