import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(500, 500);
        frame.setTitle("My Car");

        Car myCar = new Car(100, 50, 200, 100, Color.RED);

        frame.add(new JComponent() {

            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                myCar.drawVehicle(g);
            }
        });

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}